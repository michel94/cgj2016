#pragma once

class Tests{
public:
	static void testVec2() {

	}
	static void testVec3();
	static void testVec4() {

	}
	static void testMat();
	static void runTests();
};

